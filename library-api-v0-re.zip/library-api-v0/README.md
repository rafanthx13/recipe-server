# Library API

## Executar em linha de comando

http://www.appsdeveloperblog.com/run-spring-boot-app-from-a-command-line/

`mvn install`

e depois

`mvn spring-boot:run`
