package io.github.dougllasfps.domain.enums;

public enum StatusPedido {

    REALIZADO,
    CANCELADO;

}
